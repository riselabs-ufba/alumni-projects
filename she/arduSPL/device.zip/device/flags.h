// #define temperature
// #define luminosity
// #define LCD
// #define presence
// #define gas
#define USB
#define agua
// #define ethernet 
// #define wifi
